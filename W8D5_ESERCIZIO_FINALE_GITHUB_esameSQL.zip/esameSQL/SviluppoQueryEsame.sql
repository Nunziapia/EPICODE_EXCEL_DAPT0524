-- 1) Verificare che i campi definiti come PK siano univoci. 
		-- In altre parole, scrivi una query per determinare l’univocità dei valori di ciascuna PK (una query per tabella implementata). 
        
SELECT CategoryId
	, COUNT(*) AS Count
FROM Category
GROUP BY CategoryId
HAVING COUNT(*) > 1;

SELECT NationId
	, COUNT(*) AS Count
FROM Nation
GROUP BY NationId
HAVING COUNT(*) > 1;

SELECT ProductId
	, COUNT(*) AS Count
FROM Product
GROUP BY ProductId
HAVING COUNT(*) > 1;

SELECT SalesId
	, ProductId
    , COUNT(*) AS Count
FROM Sales
GROUP BY SalesId, ProductId
HAVING COUNT(*) > 1;

SELECT RegionId
	, COUNT(*) AS Count
FROM Region
GROUP BY RegionId
HAVING COUNT(*) > 1;

-- 2)Esporre l’elenco delle transazioni indicando nel result set il codice documento, 
		-- la data, il nome del prodotto, la categoria del prodotto, il nome dello stato,
		-- il nome della regione di vendita e un campo booleano valorizzato in base alla condizione
        -- che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False) 
SELECT 
    s.SalesId AS CodiceDocumento
    ,s.EmissionTime AS DataEmissione
    ,p.ProductName AS NomeProdotto
    ,c.CategoryName AS CategoriaProdotto
    ,r.RegionName AS NomeRegione
    ,CASE 
        WHEN DATEDIFF(NOW(), s.EmissionTime) > 180 THEN TRUE
        ELSE FALSE 
    END AS MaggioreDi180Giorni
FROM Sales s
JOIN 
Product p ON s.ProductId = p.ProductId
JOIN 
    Category c ON p.CategoryId = c.CategoryId
JOIN 
    Region r ON s.RegionId = r.RegionId;

-- 3)Esporre l’elenco dei prodotti che hanno venduto, 
		-- in totale, una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito. 
		-- (ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). 
		-- Nel result set devono comparire solo il codice prodotto e il totale venduto.
        
WITH MediaVenditeUltimoAnno AS (
    SELECT AVG(TotaleVendite) AS MediaVendite
    FROM (
        SELECT 
            s.ProductId
            ,SUM(s.Pieces) AS TotaleVendite
        FROM Sales s
        WHERE s.EmissionTime >= DATE_SUB(NOW(), INTERVAL 1 YEAR)
        GROUP BY s.ProductId
    ) AS Totali
)

SELECT 
    s.ProductId
    ,SUM(s.Pieces) AS TotaleVenduto
FROM Sales s
GROUP BY s.ProductId
HAVING TotaleVenduto > (SELECT MediaVendite FROM MediaVenditeUltimoAnno);
        
        
-- 4)Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.  

SELECT 
    p.ProductId
    ,p.ProductName
    ,YEAR(s.EmissionTime) AS Anno
    ,SUM(s.Pieces * p.ProductCost) AS FatturatoTotale
FROM Sales s
JOIN Product p ON s.ProductId = p.ProductId
GROUP BY 
    p.ProductId
    , Anno
ORDER BY 
    Anno
    , p.ProductId;

-- 5)Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 

SELECT 
    r.RegionName AS Stato
    ,YEAR(s.EmissionTime) AS Anno
    ,SUM(s.Pieces * p.ProductCost) AS FatturatoTotale
FROM Sales s
JOIN 
Product p ON s.ProductId = p.ProductId
JOIN 
    Region r ON s.RegionId = r.RegionId
GROUP BY 
    r.RegionName
    ,Anno
ORDER BY 
    Anno
    ,FatturatoTotale DESC;
    
-- 6)Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 
SELECT 
    c.CategoryId
    ,c.CategoryName
    ,SUM(s.Pieces) AS TotaleVendite
FROM 
    Sales s
JOIN 
    Product p ON s.ProductId = p.ProductId
JOIN 
    Category c ON p.CategoryId = c.CategoryId
GROUP BY 
    c.CategoryId
    , c.CategoryName
ORDER BY 
    TotaleVendite DESC
LIMIT 1;

-- 7)Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti. 

-- primo approccio 
SELECT 
    p.ProductId
    ,p.ProductName
FROM 
    Product p
LEFT JOIN Sales s ON p.ProductId = s.ProductId
WHERE s.ProductId IS NULL;
    
-- secondo approccio 
SELECT 
    p.ProductId
    ,p.ProductName
FROM Product p
WHERE p.ProductId NOT IN (SELECT s.ProductId FROM Sales s);

-- 8)Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili 
-- (codice prodotto, nome prodotto, nome categoria) 
  
  CREATE VIEW ProdottiDenormalizzati AS
SELECT 
    p.ProductId AS CodiceProdotto
    ,p.ProductName AS NomeProdotto
    ,c.CategoryName AS NomeCategoria
FROM Product p
JOIN 
    Category c ON p.CategoryId = c.CategoryId; 
    
    SELECT * FROM ProdottiDenormalizzati;

        
-- 9)Creare una vista per le informazioni geografiche 

CREATE VIEW InformazioniGeografiche AS
SELECT 
    n.NationId AS CodiceNazione
    ,n.NationName AS NomeNazione
    ,r.RegionId AS CodiceRegione
    ,r.RegionName AS NomeRegione
FROM 
Nation n
JOIN 
    Region r ON n.NationId = r.NationId;