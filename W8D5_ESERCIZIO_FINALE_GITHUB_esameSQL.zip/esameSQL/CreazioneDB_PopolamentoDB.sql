-- CREATE DATABASE `toysgroup`;
-- su mySQL Workbench utilizziamo invece il comando CREATE SCHEMA per creare un nuovo database 
CREATE SCHEMA `toysgroup`;
USE `toysgroup` ;

-- Per ulteriore sicurezza, durante la creazione delle tabelle, per le primary key ho attivato l'attributo auto_increment

CREATE TABLE Category (
    CategoryId INT primary key auto_increment, 
    CategoryName VARCHAR(50)
);

CREATE TABLE Product (
    ProductId INT primary key auto_increment, 
    ProductName VARCHAR(50),
    CategoryId INT ,        
    ProductCost DECIMAL(10, 2),
    FOREIGN KEY (CategoryId) REFERENCES Category(CategoryId)
);

CREATE TABLE Nation (
	NationId INt Primary Key auto_increment,
	NationName varchar(150)
    );
    
CREATE TABLE Region (
	RegionId INT auto_increment,
    RegionName varchar (50),
    -- Aggiungo unique per far si che una sola riga di Nation si riferisca ad una sola regione (region word - Europ, north ameica) 
    NationId INT unique,
    PRIMARY KEY (RegionId, NationId), 
	FOREIGN KEY (NationId) REFERENCES Nation(NationId)
    );
    
CREATE TABLE Sales(
	SalesId INT auto_increment,
	ProductId INT, -- conbinazione tra ProductId e SaldeId per assicurarmi dell'unicità delle righe 
	Pieces INT, 
	RegionId INT ,
	EmissionTime DATETIME,
    PRIMARY KEY (SalesId, ProductId),
	FOREIGN KEY (ProductId) REFERENCES Product(ProductId),
	FOREIGN KEY (RegionId) REFERENCES Region(RegionId)
);

-- FASE CREAZIONE TABELLE TERMINATA


-- POPOLAMENTO TABELLE

-- popoliamo Nations nel DB ToysGroup prendendo dei nomi di stati univoci dalla tabella dimsalesterritory nel DB adv 
INSERT INTO toysgroup.nation(NationName)
Select distinct SalesTerritoryCountry
from adv.dimsalesterritory;

-- creamo un esempio di popolamento della tabella region in cui iniziamo ad essegnare ad ogni region name un id region,
-- e iniziamo ad assegnargli una delle nazioni (in quanto durante la fase di creazione della tabella abbiamo specificato che questi valori devono essere univoci
-- e provando a popolare la tabella senza specificare almeno una nazione ci restituisce l'errore che non è possibile popolare la tabella senza specificare il valore NationId).
-- In seguito testeremo che una nazione non sia associata a piu regioni

INSERT INTO toysgroup.region(RegionName, NationId)
Select SalesTerritoryGroup
, MIN(tg_nation.NationId)
from adv.dimsalesterritory AS a_territory
join toysgroup.nation AS tg_nation
on a_territory.SalesTerritoryCountry = tg_nation.NationName
GROUP BY SalesTerritoryGroup;

INSERT INTO toysgroup.category(CategoryName)
Select distinct EnglishProductCategoryName
from adv.dimproductcategory;


-- creamo un esempio di popolamento della tabella toysgroup.product in cui iniziamo ad essegnare ad ogni prodotto una category ed un prezzo
INSERT INTO toysgroup.product(ProductName, CategoryId, ProductCost)
SELECT distinct dp.EnglishProductName, MIN(c.CategoryId), MAX(round(dp.ListPrice,2))
FROM adv.dimproduct AS dp
join toysgroup.category as c
group by dp.EnglishProductName;

-- avendo precedentemente sviluppato la logica della tabella sales andiamo a creare una query di insermimento a mano di dati
INSERT INTO Sales (ProductId, Pieces, RegionId, EmissionTime)
VALUES 
    (1, 3, 43, '2024-10-01 10:30:00'),  
    (2, 1, 42, '2024-10-02 15:45:00'),  
    (10, 2, 45, '2024-10-03 09:15:00'), 
    (4, 5, 43, '2024-10-04 12:00:00'),
    (1, 2, 43, '2024-10-05 14:20:00'), 
    (2, 4, 42, '2024-10-06 11:00:00'),  
    (10, 1, 45, '2024-10-07 16:30:00'),  
    (4, 10, 43, '2024-10-08 08:45:00'), 
    (1, 5, 42, '2024-10-09 13:15:00'),  
    (10, 3, 42, '2024-10-10 09:00:00'),  
    (2, 2, 45, '2024-10-11 10:30:00');  

-- TERMINATA LA FASE DI POPOLAZIONE DEL DATABASE

